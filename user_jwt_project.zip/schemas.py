from marshmallow import Schema, fields, validate

class itemSchema(Schema):
    id = fields.Int(dump_only=True)
    name = fields.Str(required=True)
    price = fields.Float(required=True)

class itemUpdateSchema(Schema):
    name = fields.Str()
    price = fields.Float()

class PlainUserSchema(Schema):
    id= fields.Int(dump_only=True)
    username= fields.Str(required=True)
    email = fields.Email(validate=[
            validate.Length(max=255),
            validate.Regexp(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
                            error='Invalid email address format.'),
        ])    
    phno = fields.String(validate=lambda phno: len(phno) == 10 and phno.isdigit())
    password= fields.Str(required=True, validate=validate.Length(min=8))

class UserSchema(PlainUserSchema):
    otp = fields.Int(required=True, load_only=True)

class UserLoginSchema(Schema):
    username= fields.Str(required=True)
    password= fields.Str(required=True, load_only=True, validate=validate.Length(min=8))

class UserPasswordSchema(Schema):
    otp = fields.Int(required=True)
    password= fields.Str(required=True, load_only=True, validate=validate.Length(min=8))

class UserUpdateSchema(Schema):
    id = fields.Int(dump_only=True)
    email = fields.Email(validate=[
            validate.Length(max=255),
            validate.Regexp(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
                            error='Invalid email address format.'),
        ])    
    phno = fields.String(validate=lambda phno: len(phno) == 10 and phno.isdigit())
    username = fields.Str(required=True)

class UserProfilePhotoUpdateSchema(Schema):
    profile_photo = fields.Field()
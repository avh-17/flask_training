# from db import db

# class ImageModel(db):
#     id = db.Column(db.Integer, primary_key=True)
#     img = db.Column(db.Text, unique=True, nullable=False)
#     name = db.Column(db.Text, nullable=False)
#     mimetype = db.Column(db.Text, nullable=False)
#     user_id = db.Column(db.String(), db.ForeignKey("user.id"), unique=False, nullable=False)
#     user = db.relationship("UserModel", back_populates="image")

from db import db
import os
import uuid

class UserModel(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer(), primary_key=True)
    username = db.Column(db.String(), unique=True, nullable=False)
    email = db.Column(db.String(), unique=True, nullable=False)
    phno = db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)
    otp = db.Column(db.Integer())

    image_filename = db.Column(db.String)
    image_path = db.Column(db.String)

    def save_profile_image(self, image_file):
        if image_file:
            # Generate a unique filename using UUID
            filename = str(uuid.uuid4())
            _, ext = os.path.splitext(image_file.filename)
            image_filename = f"{filename}{ext}"
            
            # Save the image file to the local system
            # image_path = os.path.join("path/to/profile/images/", image_filename)
            image_path = os.path.join("profile_images", image_filename)
            image_file.save(image_path)

            # Update the user object with the image reference
            self.image_filename = image_filename
            self.image_path = image_path


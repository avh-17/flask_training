import uuid, random
from flask import request
from flask.views import MethodView
from flask_smorest import Blueprint, abort
from flask_bcrypt import Bcrypt
from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt_identity, jwt_required, get_jwt
from blocklist import BLOCKLIST
from db import db
from models import UserModel
from schemas import PlainUserSchema, UserUpdateSchema, UserPasswordSchema, UserLoginSchema, UserSchema, UserProfilePhotoUpdateSchema
from flask import current_app
from flask_mail import Mail
from flask_mail import Message

blp = Blueprint("Users","users", description="Operations on users.")
bcrypt = Bcrypt()

def send_email(to, subject, body):
    mail = current_app.extensions['mail']
    msg = Message(subject, sender='nicemltstng@outlook.com', recipients=[to])
    msg.body = body
    mail.send(msg)

@blp.route("/register")
class UserRegister(MethodView):
    @blp.arguments(PlainUserSchema)
    def post(self, user_data):
        if UserModel.query.filter(UserModel.username == user_data["username"]).first():
            abort(409, message="A user with that username already exists.")

        user = UserModel(
            username=user_data["username"],
            email=user_data["email"],
            phno=user_data["phno"],
            password=bcrypt.generate_password_hash(user_data["password"]).decode('utf-8'),
            otp = None
        )
        db.session.add(user)
        db.session.commit()

        return {"message":"user created successfully."}, 201
    
@blp.route("/user")
class Users(MethodView):
    @blp.response(200, UserSchema(many=True))
    def get(self):
        return UserModel.query.all()

@blp.route("/user/<int:user_id>")
class User(MethodView):
    @blp.response(200, UserSchema)
    def get(self, user_id):
        user = UserModel.query.get_or_404(user_id)
        return user
    
    def delete(self, user_id):
        user = UserModel.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        return {"message":"User deleted."}, 200
    
    @jwt_required()
    @blp.arguments(UserUpdateSchema)
    @blp.response(200)
    def put(self, user_data, user_id):
        user = UserModel.query.get(user_id)
        if user:
            user.username=user_data["username"]
            user.email=user_data["email"]
            user.phno=user_data["phno"]

        db.session.add(user)
        db.session.commit()

        return {"message": f"User with ID {user_id} has been updated."}
        
@blp.route("/login")
class UserLogin(MethodView):
    @blp.arguments(UserLoginSchema)
    def post(self, user_data):
        user = UserModel.query.filter(
            UserModel.username == user_data["username"]
        ).first_or_404()
        passw = user_data["password"]
        print(user.password)
        if bcrypt.check_password_hash(user.password, passw):
            access_token = create_access_token(identity=user.id, fresh=True)
            refresh_token = create_refresh_token(identity=user.id)
            return {"access_token": access_token, "refresh_token": refresh_token}

        
        abort(401, message="Invalid credentials.")

@blp.route("/logout")
class UserLogout(MethodView):
    @jwt_required()
    def post(self):
        jti = get_jwt()["jti"]
        BLOCKLIST.add(jti)
        return {"message":"successfully logged out."}
    
@blp.route("/refresh")
class TokenRefresh(MethodView):
    @jwt_required(refresh=True)
    def post(self):
        current_user = get_jwt_identity()
        new_token = create_access_token(identity=current_user, fresh=False)
        jti = get_jwt()["jti"]
        BLOCKLIST.add(jti)
        return {"access_token":new_token}
    
@blp.route("/forgotpassword/<int:user_id>")
class UserForgotPassword(MethodView):
    @blp.arguments(UserPasswordSchema)
    @blp.response(200)
    def put(self, user_data, user_id):
        user = UserModel.query.get(user_id)
        if user and user.otp == user_data["otp"]:
            user.password = bcrypt.generate_password_hash(user_data["password"]).decode('utf-8')

        db.session.add(user)
        db.session.commit()

        return {"message": f"User with id {user_id} updated password."}
    
@blp.route('/sendmail/')
class send_email_otp(MethodView):
    @blp.response(200)
    def get(self):
        query_e = request.args
        email = query_e.get('email')
        user = UserModel.query.filter_by(email=email).first_or_404()
        otp = random.randint(100000,999999)
        user.otp = otp
        db.session.commit()
        
        try:
            send_email(email, 'OTP for reset password', str(otp))
        except Exception as e:
            return f'Error sending email: {str(e)}', 500
        
        return 'OTP sent successfully!'

@blp.route("/userprofile/<int:user_id>")
class User(MethodView):
    # @jwt_required(fresh=True)
    @blp.arguments(UserProfilePhotoUpdateSchema)
    @blp.response(201)
    def put(self, user_data, user_id):
        user = UserModel.query.get_or_404(user_id)
        # Update the profile photo
        image_file = request.files.get('profile_photo')
        if image_file:
            user.save_profile_image(image_file)
        db.session.commit()
        return {"message":"profile photo uploaded"}

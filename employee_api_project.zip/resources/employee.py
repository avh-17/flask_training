from flask import request, jsonify
from flask_smorest import Blueprint, abort
from db import db
from models.__init__ import Employee
from datetime import datetime
from flask.views import MethodView
from sqlalchemy import or_
from schemas import EmployeeSchema, EmployeeListSchema, EmployeeSchemaWithoutID, EmployeeUpdateSchema

ebp = Blueprint('employee', __name__, description ="Employee Operations")

@ebp.route('/employee')
class EmployeeList(MethodView):

    @ebp.response(200, EmployeeListSchema)
    def get(self):
        employees = Employee.query.all()
        return {'employees': employees}
    
    @ebp.arguments(EmployeeSchemaWithoutID)
    @ebp.response(200, EmployeeSchemaWithoutID)
    def post(self, data):
        h_date = str(data['hire_date'])
        new_employee = Employee(
            name=data['name'],
            email=data['email'],
            phone=data['phone'],
            address=data['address'],
            department=data['department'],
            position=data['position'],
            salary=data['salary'],
            hire_date=datetime.strptime(h_date, '%Y-%m-%d').date()
        )
        db.session.add(new_employee)
        db.session.commit()
        return new_employee
    

@ebp.route('/employee/<int:e_id>')
class EmployeeID(MethodView):
    @ebp.response(200, EmployeeSchema)
    def get(self, e_id):
        employee = Employee.query.get_or_404(e_id)
        return employee

    def delete(self,e_id):
        employee = Employee.query.get(e_id)
        if not employee:
            abort(404, message=f"Employee with ID {e_id} not found")

        db.session.delete(employee)
        db.session.commit()
        return {"message": f"Employee with ID {e_id} deleted successfully"}, 200
    
    @ebp.arguments(EmployeeUpdateSchema)
    @ebp.response(200)
    def put(self, data, e_id):
        employee = Employee.query.get(e_id)
        if not employee:
            abort(404, message="Employee not found")
        data = request.get_json()
        employee.name = data['name']
        employee.email = data['email']
        employee.phone = data['phone']
        employee.address = data['address']
        employee.department = data['department']
        employee.position = data['position']
        employee.salary = data['salary']
        db.session.commit()
        return jsonify({'message': 'Employee updated successfully!'}), 200

@ebp.route('/searchbydep')
class EmployeeSearchDep(MethodView):
    @ebp.response(200, EmployeeListSchema)
    def get(self):
        query_e = request.args
        emp=query_e.get('department')
        employees = Employee.query.filter_by(department=emp).all()
        return {'employees': employees}
    
@ebp.route('/searchbypos')
class EmployeeSearchPos(MethodView):
    @ebp.response(200, EmployeeListSchema)
    def get(self):
        query_e = request.args
        emp=query_e.get('position')
        employees = Employee.query.filter_by(position=emp).all()
        return {'employees': employees}
    
@ebp.route('/searchname')
class EmployeeSearchName(MethodView):
    @ebp.response(200, EmployeeListSchema)
    def get(self):
        query_params = request.args
        search_query = query_params.get('name')
        if search_query:
            employees = Employee.query.filter(or_(Employee.name.ilike(f'{search_query}%'), Employee.email.ilike(f'{search_query}%')))
        else:
            employees = Employee.query.all()   
        return {'employees': employees}
    
@ebp.route("/searchbyposanddep")
class EmployeeSearchByPosAndDep(MethodView):
    @ebp.response(200, EmployeeListSchema)
    def get(self):
        query_params = request.args
        search_query_pos = query_params.get('pos')
        search_query_dep = query_params.get('dep')
        if search_query_dep and search_query_pos:
            employees = Employee.query.filter_by(position=search_query_pos, department=search_query_dep).all()
        elif search_query_dep:
            employees = Employee.query.filter_by(department=search_query_dep).all()
        elif search_query_pos:
            employees = Employee.query.filter_by(position=search_query_pos).all()
        else:
            employees = Employee.query.all()
        return {'employees': employees}

        
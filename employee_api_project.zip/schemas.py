from marshmallow import fields, Schema

class EmployeeSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True)
    email = fields.Email(required=True)
    phone = fields.String(required=True)
    address = fields.String(required=True)
    department = fields.String(required=True)
    position = fields.String(required=True)
    salary = fields.Float(required=True)
    hire_date = fields.Date(required=True)

class EmployeeUpdateSchema(Schema):
    name = fields.String(required=True)
    email = fields.Email(required=True)
    phone = fields.String(required=True)
    address = fields.String(required=True)
    department = fields.String(required=True)
    position = fields.String(required=True)
    salary = fields.Float(required=True)

class EmployeeSchemaWithoutID(Schema):
    name = fields.String(required=True)
    email = fields.Email(required=True)
    phone = fields.String(required=True)
    address = fields.String(required=True)
    department = fields.String(required=True)
    position = fields.String(required=True)
    salary = fields.Float(required=True)
    hire_date = fields.Date(required=True)

class EmployeeListSchema(Schema):
    employees = fields.List(fields.Nested(EmployeeSchema()))

from flask import Flask
from flask_smorest import Api
from resources.employee import ebp
from flask_swagger_ui import get_swaggerui_blueprint
import models
from db import db

app = Flask(__name__)

SWAGGER_URL = '/api/docs'
API_URL = '/static/swagger.json'

swaggerui_blueprint = get_swaggerui_blueprint(
    SWAGGER_URL,  
    API_URL,
    config={  
        'app_name': "Test application"
    },

)

app.register_blueprint(swaggerui_blueprint)

app.config["PROPAGATE_EXCEPTIONS"]= True
app.config["API_TITLE"]="Employee"
app.config["API_VERSION"]="v1"
app.config["OPENAPI_VERSION"]= "3.0.3"
app.config["OPENAPI_URL_PREFIX"]="/"
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql+psycopg2://postgres:Valtech123@localhost/Employee'

db.init_app(app)
with app.app_context():
    db.create_all()

api= Api(app)

app.register_blueprint(ebp)
